classdef elem_idx_t
    properties
        blk (1,1) {mustBeInteger}
        i   (1,1) {mustBeInteger}
        j   (1,1) {mustBeInteger}
        k   (1,1) {mustBeInteger}
    end
end
